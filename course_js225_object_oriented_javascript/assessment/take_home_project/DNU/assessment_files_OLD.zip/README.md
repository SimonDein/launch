# README

This is a collection of my notes, assumptions and decisions regarding the Todo App.

##Overview

###Concepts of Interest

You should demonstrate with the take-home project your mastery of the following:

- Organizing code into its respective objects
- Creating and using private data
- IIFEs
- Using object creation patterns
- Using function execution contexts

###About

The application you're going to build is a todo app.



## Specifications

### todoManager(todoList) - wrappper function

Always returns a copy of the array.

**Methods**

* **todos**
  * returns all `todo` objects from todoList
  * **must be copy**
* **completedTodos**
  * returns all completede `todo` objects from todolist
* **todosBetween(month, year)**
  * returns all `todo` from `todoList` with corrosponding month and year
* **completedTodosWithin(monthYear, monthYear)**
  * returns all completed  `todo` objects with corrosponding month and year



### TodoList(todoSet) - constructor function

The `todoList` **has** a collection (**array**) **of** `todo` objects.

**Provides** an **interface** for manipulating its `todo`'s.

**Returns** a **new** collection (**array**) object **when** a **method** returns all or a subset of `todo`'s on a list.

**Disallows** **users/other** objects **from manipulating** the **values** of `todo` objects directly (it's `todo`'s should be **private**)

#### TodoObject (created object)

- **todos = todoset === undefined ? [] || createNTodos(todoSet)**
  - Private (ie. not a property on the object)

#### TodoObject methods:

* **addTodo(todoObj)**
  * adds a new `todo` to `todos`
* **deleteTodo(todoObj)**
  * deletes a `todo` from `todos`
* **updateTodo(todoObj)**
  * updates a `todo` form `todos`
* **getTodoById(id)**
  * returns a `todo` by id from `todos`



### Todo(todoData)

new `todo` objects will be created from an object with the following key-value pairs: `title`, `month`, `year` and `description`:

```
var todoData = {
  title: 'Buy Milk',
  month: '1',
  year: '2017',
  description: 'Milk for baby',
};
```

***You may not add or remove any properties from what is in the specification for `todo` objects from LS!***

####TodoObject (created object)

- **this.title = todoData.title**
  - String
    - Can contain any characters (choice should be left to user)
    - Doesnt' have to be unique (choice should be left to user)
- **this.month = todoData.month**
  - String
    - The string number **must** be between 1-12
- **this.year = todoData.year**
  - String
- **this.description = todoData.description**
  - String
- **this.completed = false**
  - Boolean (Binary state only)
    - **Default** to **false**
- **this.id**
  - Number
    - Integer
    - **must be unique**
      - between all lists in case we want to move `todo`'s between lists.

####TodoObject.prototype (shared behavior)

- **isWithinMonthYear(month, year)**
  - **month**
    - string
  - **year**
    - string

## Notes

Testing has been the biggest suprise doing this project. I spend way too much time thinking - without really coming up with a great solution - about how to test. The stress got to me and the flow between testing and writing code was not ideal. I really wanted to come up with a nice system, but failed.

I found it quite hard to test with private data, and is really something i need to practice. Soon after i started writing tests i also realised that if i *really* were to test properly, i was going to write a **lot** of tests! I was kinda paralyzed by this realisation and started trying to read up on testing and looking through the API for `jest`, and realized that if i was to actually finish the program i had to put testing aside.

I'm aware that i lack tests for my `todoManager` as well as coverage overall.

I spend most of my time going back and forward with some ideas for how to make `todo`'s available without make it possible to directly manipulate them. I considered deep copies, but that would mean a lot more code simply not to let anything touch them except through my interface. I went with property descriptors instead - setting all values on the `todo`'s to `writable: false` and `configurable: true` to make it clear that only `updateTodo` should be used.

### Errors

* How to handle errors?

  * Custom errors?

  * Input validation

    * If handled `todoList` or `todoManager`
      * Validation should be done at highest level possible
        * Seperation of concerns (validation & business logic - at least to some degree)
    * Should be handled before reaching  `todoList` or `todoManager`
      * Separation of concerns
        * Data is validated before even introduced to business logic
          * Input only reaches inner logic if we know we want to operate on it
          * Seperation of concerns
          * Bad input can't introduce errors at lower levels that'd compromise functionality at higher levels

    



## Assumptions & Decisions

## todoList

The `todoList` should have a collection of `todo` objects. I assume order will be significant as i assume we want the todos in the order they are added by default and the choice of having duplicate values in a `todoList` should be left up to the user - which together make me choose an array as the data structure here. Speed wise this choice has it pros and cons - adding a new `todo` will be very fast - deleting the oldest `todo` will be very slow. I assume deletion won't be too important as we are proably going to access/manipulate state (whether a `todo` is done) more than actually deleting a specific `todo`, and reading/writing from/to an array is also very fast.

